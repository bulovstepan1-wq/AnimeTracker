package com.example.animetracker

import android.annotation.SuppressLint
import android.os.Bundle
import android.net.Uri
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import coil3.compose.AsyncImage
import com.example.animetracker.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

private val Bg = Color(0xFF0B0910)
private val Surface = Color(0xFF17131F)
private val Card = Color(0xFF1D1826)
private val Purple = Color(0xFF8B5CF6)
private val Muted = Color(0xFFA8A0B5)
private val Gold = Color(0xFFFFC857)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AnimeTrackerTheme { AnimeTrackerApp() } }
    }
}

@Composable
fun AnimeTrackerTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Surface, primary = Purple,
        onBackground = Color.White, onSurface = Color.White
    ), content = content)
}

data class UiState(
    val catalog: List<Anime> = emptyList(),
    val search: List<Anime> = emptyList(),
    val selected: Anime? = null,
    val episodes: List<EpisodeDto> = emptyList(),
    val trailerUrl: String? = null,
    val favorites: Set<String> = emptySet(),
    val ratings: Map<String, Int> = emptyMap(),
    val progress: Map<String, Int> = emptyMap(),
    val voicePreferences: Map<String, String> = emptyMap(),
    val qualityPreferences: Map<String, String> = emptyMap(),
    val loading: Boolean = false,
    val loadingMore: Boolean = false,
    val hasNext: Boolean = true,
    val page: Int = 0,
    val searchPage: Int = 0,
    val error: String? = null
)

class AnimeViewModel : ViewModel() {
    private val api = AnimeApiProvider.api
    private lateinit var prefs: Prefs
    private val _state = MutableStateFlow(UiState())
    val state = _state.asStateFlow()

    fun init(context: android.content.Context) {
        if (::prefs.isInitialized) return
        prefs = Prefs(context.applicationContext)
        viewModelScope.launch {
            prefs.favorites.collect { ids -> _state.value = _state.value.copy(favorites = ids) }
        }
        viewModelScope.launch {
            prefs.ratings.collect { ratings -> _state.value = _state.value.copy(ratings = ratings) }
        }
        viewModelScope.launch {
            prefs.progress.collect { progress -> _state.value = _state.value.copy(progress = progress) }
        }
        viewModelScope.launch {
            prefs.voicePreferences.collect { voices -> _state.value = _state.value.copy(voicePreferences = voices) }
        }
        viewModelScope.launch {
            prefs.qualityPreferences.collect { qualities -> _state.value = _state.value.copy(qualityPreferences = qualities) }
        }
        loadNextCatalog()
    }

    fun loadNextCatalog() {
        if (_state.value.loadingMore || !_state.value.hasNext) return
        viewModelScope.launch {
            val first = _state.value.page == 0
            _state.value = _state.value.copy(
                loading = first, loadingMore = !first, error = null
            )
            runCatching {
                api.top(page = _state.value.page + 1)
            }.onSuccess { response ->
                val mapped = response.data.map { it.toAnime() }
                val merged = (_state.value.catalog + mapped).distinctBy { it.id }
                _state.value = _state.value.copy(
                    catalog = merged,
                    page = _state.value.page + 1,
                    hasNext = response.pagination?.has_next_page ?: false,
                    loading = false, loadingMore = false
                )
            }.onFailure {
                _state.value = _state.value.copy(
                    loading = false, loadingMore = false,
                    error = "Нет соединения с интернетом. Нажмите, чтобы повторить."
                )
            }
        }
    }

    fun search(query: String) {
        if (query.isBlank()) {
            _state.value = _state.value.copy(search = emptyList(), searchPage = 0)
            return
        }
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            runCatching { api.search(query, page = 1) }
                .onSuccess {
                    _state.value = _state.value.copy(
                        search = it.data.map { dto -> dto.toAnime() }.distinctBy { a -> a.id },
                        searchPage = 1, loading = false
                    )
                }.onFailure {
                    _state.value = _state.value.copy(loading = false, error = "Поиск временно недоступен")
                }
        }
    }

    fun open(anime: Anime) = viewModelScope.launch {
        _state.value = _state.value.copy(selected = anime, episodes = emptyList(), trailerUrl = null, loading = true)
        runCatching { api.episodes(anime.id).data }.onSuccess { eps ->
            _state.value = _state.value.copy(episodes = eps, loading = false)
        }.onFailure { _state.value = _state.value.copy(loading = false) }
        runCatching { api.videos(anime.id).data?.promo?.trailer?.embed_url }.onSuccess { url ->
            _state.value = _state.value.copy(trailerUrl = url)
        }
    }

    fun close() { _state.value = _state.value.copy(selected = null) }
    fun toggleFavorite(id: Int) { viewModelScope.launch { prefs.toggleFavorite(id) } }
    fun rate(id: Int, rating: Int) { viewModelScope.launch { prefs.setRating(id, rating) } }
    fun progress(id: Int, episode: Int) { viewModelScope.launch { prefs.setProgress(id, episode) } }
    fun setVoice(id: Int, voice: String) { viewModelScope.launch { prefs.setVoice(id, voice) } }
    fun setQuality(id: Int, quality: String) { viewModelScope.launch { prefs.setQuality(id, quality) } }
}

@Composable
fun AnimeTrackerApp(vm: AnimeViewModel = viewModel()) {
    val context = LocalContext.current
    LaunchedEffect(Unit) { vm.init(context) }
    val state by vm.state.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }

    state.selected?.let { selected ->
        DetailScreen(
            anime = selected, episodes = state.episodes, trailerUrl = state.trailerUrl,
            saved = selected.id.toString() in state.favorites,
            userRating = state.ratings[selected.id.toString()],
            lastEpisode = state.progress[selected.id.toString()] ?: 0,
            selectedVoice = state.voicePreferences[selected.id.toString()] ?: "Авто",
            selectedQuality = state.qualityPreferences[selected.id.toString()] ?: "Авто",
            loading = state.loading,
            onFavorite = vm::toggleFavorite, onRate = vm::rate, onProgress = vm::progress,
            onVoice = vm::setVoice, onQuality = vm::setQuality, onBack = vm::close
        )
        return
    }

    Scaffold(containerColor = Bg, bottomBar = { BottomBar(tab) { tab = it } }) { pad ->
        when (tab) {
            0 -> HomeScreen(pad, state, query, { query = it; vm.search(it) }, vm::open, vm::loadNextCatalog)
            1 -> BrowseScreen(pad, state, query, { query = it; vm.search(it) }, vm::open, vm::loadNextCatalog)
            2 -> BookmarkScreen(pad, state, vm::open)
            3 -> FeedScreen(pad)
            4 -> ProfileScreen(pad, state)
        }
    }
}

@Composable
fun SearchBar(value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
        placeholder = { Text("Поиск по каталогу", color = Muted) },
        leadingIcon = { Icon(Icons.Default.Search, null) },
        trailingIcon = { if (value.isNotBlank()) IconButton({ onChange("") }) { Icon(Icons.Default.Close, null) } },
        shape = RoundedCornerShape(28.dp),
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedBorderColor = Color.Transparent, focusedBorderColor = Color.Transparent,
            unfocusedContainerColor = Card, focusedContainerColor = Card
        )
    )
}

@Composable
fun HomeScreen(
    pad: PaddingValues, state: UiState, query: String, onQuery: (String) -> Unit,
    onOpen: (Anime) -> Unit, onMore: () -> Unit
) {
    Column(Modifier.padding(pad).fillMaxSize()) {
        SearchBar(query, onQuery)
        if (query.isBlank()) {
            SectionTitle("Каталог аниме", "Реальные данные из Jikan • интернет нужен")
            AnimeList(
                list = state.catalog, state = state, onOpen = onOpen,
                onEndReached = onMore
            )
        } else {
            SectionTitle("Результаты", "По запросу «$query»")
            AnimeList(state.search, state, onOpen, {})
        }
    }
}

@Composable
fun BrowseScreen(
    pad: PaddingValues, state: UiState, query: String, onQuery: (String) -> Unit,
    onOpen: (Anime) -> Unit, onMore: () -> Unit
) {
    Column(Modifier.padding(pad).fillMaxSize()) {
        SearchBar(query, onQuery)
        SectionTitle("Обзор", "Бесконечная прокрутка каталога")
        AnimeList(
            if (query.isBlank()) state.catalog else state.search,
            state, onOpen,
            if (query.isBlank()) ({ onMore() }) else ({ })
        )
    }
}

@Composable
fun BookmarkScreen(pad: PaddingValues, state: UiState, onOpen: (Anime) -> Unit) {
    val saved = state.catalog.filter { it.id.toString() in state.favorites }
    Column(Modifier.padding(pad).fillMaxSize()) {
        SearchBar("", {})
        SectionTitle("Закладки", "${state.favorites.size} сохранено")
        if (saved.isEmpty()) Empty("Закладки пусты", "Открывайте карточки и добавляйте тайтлы") else
            AnimeList(saved, state, onOpen, {})
    }
}

@Composable
fun FeedScreen(pad: PaddingValues) {
    Column(Modifier.padding(pad).fillMaxSize()) {
        SectionTitle("Лента", "Активность приложения")
        LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(listOf("🔥 Каталог обновлён", "🎬 Добавлены трейлеры тайтлов", "⭐ Можно поставить свою оценку 1–10", "🔖 Закладки сохраняются на устройстве")) { item ->
                Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(item, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("Сейчас", color = Muted, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(pad: PaddingValues, state: UiState) {
    Column(Modifier.padding(pad).fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(30.dp))
        Box(Modifier.size(96.dp).clip(RoundedCornerShape(48.dp)).background(Purple), contentAlignment = Alignment.Center) {
            Text("S", fontSize = 38.sp, fontWeight = FontWeight.Bold)
        }
        Text("St1ksArm", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Text("AnimeTracker", color = Muted)
        Spacer(Modifier.height(28.dp))
        Text("Закладки: ${state.favorites.size}", fontSize = 20.sp)
        Text("Мои оценки: ${state.ratings.size}", fontSize = 20.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
fun AnimeList(
    list: List<Anime>, state: UiState, onOpen: (Anime) -> Unit, onEndReached: () -> Unit
) {
    val lazyState = rememberLazyListState()
    LaunchedEffect(list.size) {
        snapshotFlow { lazyState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1 }
            .collect { last ->
                if (last >= list.lastIndex - 5 && list.isNotEmpty()) onEndReached()
            }
    }
    if (list.isEmpty() && !state.loading) {
        Empty("Ничего не найдено", "Попробуйте другой запрос")
    }
    LazyColumn(
        state = lazyState,
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(list, key = { it.id }) { anime ->
            AnimeCard(anime, anime.id.toString() in state.favorites, state.ratings[anime.id.toString()], onOpen)
        }
        if (state.loadingMore) {
            item { Box(Modifier.fillMaxWidth().padding(22.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
        }
        if (!state.hasNext && list.isNotEmpty()) {
            item { Text("Каталог закончился", color = Muted, modifier = Modifier.fillMaxWidth().padding(20.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center) }
        }
    }
}

@Composable
fun AnimeCard(anime: Anime, saved: Boolean, rating: Int?, onOpen: (Anime) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onOpen(anime) },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Card)
    ) {
        Row(Modifier.padding(10.dp)) {
            AsyncImage(
                model = anime.image, contentDescription = anime.title,
                modifier = Modifier.width(112.dp).height(164.dp).clip(RoundedCornerShape(13.dp)),
                contentScale = ContentScale.Crop
            )
            Column(Modifier.weight(1f).padding(start = 13.dp)) {
                Text(anime.title, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    "${anime.type} • ${anime.year ?: "—"}",
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp)
                )
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 7.dp)) {
                    Text("★ ${anime.score?.let { String.format(Locale.US, "%.1f", it) } ?: "—"}", color = Gold, fontWeight = FontWeight.Bold)
                    Text("  ${anime.episodes ?: "?"} эп.", color = Muted)
                }
                if (rating != null) Text("Ваша оценка: $rating/10 ★", color = Purple, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
                Text(
                    anime.synopsis.ifBlank { "Описание пока отсутствует." },
                    color = Muted, fontSize = 13.sp, lineHeight = 18.sp, maxLines = 4,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 7.dp)
                )
                Text(if (saved) "🔖 В закладках" else "Открыть тайтл", color = Purple, fontSize = 12.sp, modifier = Modifier.padding(top = 7.dp))
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun TrailerPlayer(url: String) {
    AndroidView(
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                webViewClient = WebViewClient()
                webChromeClient = WebChromeClient()
                setBackgroundColor(android.graphics.Color.BLACK)
            }
        },
        update = { it.loadUrl(url) },
        modifier = Modifier.fillMaxWidth().height(215.dp)
    )
}

@Composable
fun DirectMediaPlayer(
    url: String,
    preferredVoice: String,
    preferredQuality: String,
    onVoiceDetected: (String) -> Unit,
    onQualityDetected: (String) -> Unit,
    onQualitySelected: (String) -> Unit
) {
    val context = LocalContext.current
    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(androidx.media3.common.MediaItem.fromUri(Uri.parse(url)))
            trackSelectionParameters = trackSelectionParameters.buildUpon()
                .clearVideoSizeConstraints()
                .clearViewportSizeConstraints()
                .setMaxVideoSize(3840, 2160)
                .build()
            prepare()
            playWhenReady = false
        }
    }
    var audioTracks by remember { mutableStateOf(emptyList<AudioChoice>()) }
    var videoTracks by remember { mutableStateOf(emptyList<VideoChoice>()) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                val audios = mutableListOf<AudioChoice>()
                val videos = mutableListOf<VideoChoice>()
                tracks.groups.forEachIndexed { groupIndex, group ->
                    if (group.type == C.TRACK_TYPE_AUDIO) {
                        for (i in 0 until group.length) {
                            val f = group.getTrackFormat(i)
                            val label = f.label?.takeIf { it.isNotBlank() }
                                ?: f.language?.let { lang -> "Аудио • $lang" }
                                ?: "Аудиодорожка ${i + 1}"
                            audios += AudioChoice(groupIndex, i, label)
                        }
                    }
                    if (group.type == C.TRACK_TYPE_VIDEO) {
                        for (i in 0 until group.length) {
                            val f = group.getTrackFormat(i)
                            val h = f.height
                            val w = f.width
                            if (h > 0 && h <= 2160 && w > 0) {
                                val label = when {
                                    h >= 2160 -> "2160p • 4K"
                                    h >= 1440 -> "1440p • 2K"
                                    h >= 1080 -> "1080p • Full HD"
                                    h >= 720 -> "720p • HD"
                                    h >= 480 -> "480p"
                                    else -> "${h}p"
                                }
                                val bitrate = if (f.bitrate > 0) " • ${f.bitrate / 1000} кбит/с" else ""
                                videos += VideoChoice(groupIndex, i, "$label$bitrate", w, h)
                            }
                        }
                    }
                }
                audioTracks = audios.distinctBy { it.label }
                videoTracks = videos.sortedByDescending { it.height }.distinctBy { it.height }
                audioTracks.firstOrNull()?.let { if (preferredVoice == "Авто") onVoiceDetected(it.label) }
                videoTracks.firstOrNull()?.let { if (preferredQuality == "Авто") onQualityDetected("Авто") }
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        AndroidView(
            factory = { PlayerView(it).apply { this.player = player; useController = true } },
            modifier = Modifier.fillMaxWidth().height(230.dp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            AudioTrackPicker(
                tracks = audioTracks,
                selected = preferredVoice,
                onSelect = { choice ->
                    val group = player.currentTracks.groups.getOrNull(choice.groupIndex)
                    if (group != null) {
                        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                            .setOverrideForType(androidx.media3.common.TrackSelectionOverride(group.mediaTrackGroup, listOf(choice.trackIndex)))
                            .build()
                        onVoiceDetected(choice.label)
                    }
                },
                modifier = Modifier.weight(1f)
            )
            QualityPicker(
                tracks = videoTracks,
                selected = preferredQuality,
                onSelect = { choice ->
                    if (choice == null) {
                        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                            .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                            .clearVideoSizeConstraints()
                            .clearViewportSizeConstraints()
                            .setMaxVideoSize(3840, 2160)
                            .build()
                        onQualityDetected("Авто")
                        onQualitySelected("Авто")
                    } else {
                        val group = player.currentTracks.groups.getOrNull(choice.groupIndex)
                        if (group != null) {
                            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                                .setOverrideForType(androidx.media3.common.TrackSelectionOverride(group.mediaTrackGroup, listOf(choice.trackIndex)))
                                .build()
                            onQualityDetected(choice.shortLabel)
                            onQualitySelected(choice.shortLabel)
                        }
                    }
                },
                modifier = Modifier.weight(1f)
            )
        }
        Text("Доступное качество зависит от исходного HLS/DASH-потока и возможностей телефона.", color = Muted, fontSize = 11.sp)
    }
}

data class AudioChoice(val groupIndex: Int, val trackIndex: Int, val label: String)
data class VideoChoice(val groupIndex: Int, val trackIndex: Int, val label: String, val width: Int, val height: Int) {
    val shortLabel: String get() = when {
        height >= 2160 -> "2160p • 4K"
        height >= 1440 -> "1440p • 2K"
        height >= 1080 -> "1080p • Full HD"
        height >= 720 -> "720p • HD"
        height >= 480 -> "480p"
        else -> "${height}p"
    }
}

@Composable
fun AudioTrackPicker(tracks: List<AudioChoice>, selected: String, onSelect: (AudioChoice) -> Unit, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text("🎙️ ${selected.take(16)}", maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            if (tracks.isEmpty()) {
                DropdownMenuItem(text = { Text("Авто / нет дорожек") }, onClick = { expanded = false })
            } else tracks.forEach { choice ->
                DropdownMenuItem(text = { Text(choice.label) }, onClick = { onSelect(choice); expanded = false })
            }
        }
    }
}

@Composable
fun QualityPicker(tracks: List<VideoChoice>, selected: String, onSelect: (VideoChoice?) -> Unit, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text("⚙️ ${selected.take(14)}", maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(text = { Text("Авто") }, onClick = { onSelect(null); expanded = false })
            tracks.sortedByDescending { it.height }.forEach { choice ->
                DropdownMenuItem(text = { Text(choice.label) }, onClick = { onSelect(choice); expanded = false })
            }
        }
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun DetailScreen(
    anime: Anime, episodes: List<EpisodeDto>, trailerUrl: String?, saved: Boolean,
    userRating: Int?, lastEpisode: Int, selectedVoice: String, selectedQuality: String, loading: Boolean,
    onFavorite: (Int) -> Unit, onRate: (Int, Int) -> Unit,
    onProgress: (Int, Int) -> Unit, onVoice: (Int, String) -> Unit, onQuality: (Int, String) -> Unit, onBack: () -> Unit
) {
    val context = LocalContext.current
    var currentVoice by remember(selectedVoice) { mutableStateOf(selectedVoice) }
    var currentQuality by remember(selectedQuality) { mutableStateOf(selectedQuality) }
    val directVideo = trailerUrl?.let {
        val lower = it.lowercase()
        it.takeIf { lower.endsWith(".m3u8") || lower.endsWith(".mp4") || lower.contains(".m3u8?") || lower.contains(".mp4?") }
    }

    Scaffold(
        containerColor = Bg,
        topBar = {
            TopAppBar(
                title = { Text(anime.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onBack) { Icon(Icons.Default.ArrowBack, null) } },
                actions = { IconButton({ onFavorite(anime.id) }) { Icon(if (saved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
            )
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(bottom = 32.dp)) {
            item {
                AsyncImage(model = anime.image, contentDescription = anime.title, modifier = Modifier.fillMaxWidth().height(330.dp), contentScale = ContentScale.Crop)
                Column(Modifier.padding(18.dp)) {
                    Text(anime.title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("${anime.type} • ${anime.status} • ${anime.episodes ?: "?"} эп.", color = Muted, modifier = Modifier.padding(top = 7.dp))
                    Text("★ ${anime.score?.let { String.format(Locale.US, "%.1f", it) } ?: "—"}", color = Gold, fontSize = 19.sp, modifier = Modifier.padding(top = 8.dp))
                    Text(anime.synopsis.ifBlank { "Описание отсутствует." }, lineHeight = 22.sp, modifier = Modifier.padding(top = 14.dp))

                    Text("Ваша оценка", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 22.dp))
                    LazyRow(
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        items((1..10).toList()) { n ->
                            FilterChip(selected = userRating == n, onClick = { onRate(anime.id, n) }, label = { Text("$n") })
                        }
                    }
                    userRating?.let { Text("Вы поставили $it/10 ★", color = Purple, modifier = Modifier.padding(top = 7.dp)) }

                    if (directVideo != null) {
                        Text("Встроенный плеер", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 22.dp, bottom = 8.dp))
                        Text("Качество: $currentQuality • Озвучка: $currentVoice", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
                        DirectMediaPlayer(
                            url = directVideo,
                            preferredVoice = currentVoice,
                            preferredQuality = currentQuality,
                            onVoiceDetected = { detected ->
                                currentVoice = detected
                                onVoice(anime.id, detected)
                            },
                            onQualityDetected = { detected ->
                                currentQuality = detected
                            },
                            onQualitySelected = { selected ->
                                currentQuality = selected
                                onQuality(anime.id, selected)
                            }
                        )
                    } else if (trailerUrl != null) {
                        Text("Трейлер", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 22.dp, bottom = 8.dp))
                        TrailerPlayer(trailerUrl)
                        Text(
                            "Этот источник не отдаёт отдельные аудиодорожки приложению, поэтому список озвучек определяется самим видеосервисом.",
                            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 7.dp)
                        )
                    } else {
                        Text("Видео для этого тайтла не найдено.", color = Muted, modifier = Modifier.padding(top = 18.dp))
                    }

                    anime.url?.let { url ->
                        OutlinedButton(onClick = { context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))) }, modifier = Modifier.padding(top = 16.dp)) {
                            Text("Открыть страницу тайтла")
                        }
                    }

                    Text("Серии", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 24.dp, bottom = 8.dp))
                    if (lastEpisode > 0) {
                        Text("Продолжить с серии $lastEpisode", color = Purple, modifier = Modifier.padding(bottom = 8.dp))
                    }
                    if (loading) CircularProgressIndicator()
                }
            }
            items(episodes, key = { it.mal_id }) { ep ->
                val watched = ep.mal_id <= lastEpisode
                ListItem(
                    headlineContent = { Text("Серия ${ep.mal_id}: ${ep.title ?: "Без названия"}") },
                    supportingContent = { Text(if (watched) "✓ Просмотрено" else (ep.aired ?: "")) },
                    leadingContent = { Text("${ep.mal_id}", fontWeight = FontWeight.Bold) },
                    trailingContent = {
                        TextButton(onClick = { onProgress(anime.id, ep.mal_id) }) {
                            Text(if (watched) "Просмотрено" else "Отметить")
                        }
                    },
                    modifier = Modifier.clickable { onProgress(anime.id, ep.mal_id) }
                )
                HorizontalDivider()
            }
        }
    }
}

@Composable fun SectionTitle(title: String, subtitle: String) {
    Column(Modifier.padding(18.dp, 18.dp, 18.dp, 8.dp)) {
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, modifier = Modifier.padding(top = 4.dp))
    }
}
@Composable fun Empty(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.SearchOff, null, tint = Muted, modifier = Modifier.size(48.dp))
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Text(subtitle, color = Muted, modifier = Modifier.padding(top = 6.dp))
    }
}
@Composable fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xFF17131F)) {
        val icons = listOf(Icons.Default.Home, Icons.Default.Explore, Icons.Default.Bookmark, Icons.Default.Article, Icons.Default.Person)
        val labels = listOf("Главная", "Обзор", "Закладки", "Лента", "Профиль")
        icons.forEachIndexed { i, icon ->
            NavigationBarItem(selected = selected == i, onClick = { onSelect(i) }, icon = { Icon(icon, null) }, label = { Text(labels[i]) })
        }
    }
}
