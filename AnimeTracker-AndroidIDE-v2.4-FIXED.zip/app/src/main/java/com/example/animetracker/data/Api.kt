package com.example.animetracker.data

import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface JikanApi {
    @GET("top/anime")
    suspend fun top(@Query("page") page: Int = 1, @Query("filter") filter: String? = null): TopResponse

    @GET("anime")
    suspend fun search(@Query("q") query: String, @Query("page") page: Int = 1): TopResponse

    @GET("anime/{id}")
    suspend fun detail(@Path("id") id: Int): DetailResponse

    @GET("anime/{id}/episodes")
    suspend fun episodes(@Path("id") id: Int, @Query("page") page: Int = 1): EpisodesResponse

    @GET("anime/{id}/videos")
    suspend fun videos(@Path("id") id: Int): VideosResponse
}

data class TopResponse(
    val data: List<AnimeDto> = emptyList(),
    val pagination: Pagination? = null
)
data class DetailResponse(val data: AnimeDto)
data class EpisodesResponse(val data: List<EpisodeDto> = emptyList(), val pagination: Pagination? = null)
data class VideosResponse(val data: VideoData? = null)
data class VideoData(
    val promo: PromoDto? = null,
    val episodes: List<VideoEpisodeDto> = emptyList()
)
data class PromoDto(
    val title: String?,
    val trailer: TrailerDto?
)
data class TrailerDto(
    val youtube_id: String?,
    val url: String?,
    val embed_url: String?,
    val images: VideoImages?
)
data class VideoImages(val image_url: String?)
data class VideoEpisodeDto(
    val mal_id: Int?,
    val title: String?,
    val episode: String?,
    val url: String?,
    val images: VideoImages?
)
data class Pagination(val last_visible_page: Int = 1, val has_next_page: Boolean = false)
data class EpisodeDto(val mal_id: Int, val title: String?, val title_japanese: String?, val aired: String?, val score: Double?)

data class AnimeDto(
    val mal_id: Int,
    val title: String,
    val title_english: String?,
    val synopsis: String?,
    val type: String?,
    val status: String?,
    val episodes: Int?,
    val score: Double?,
    val rank: Int?,
    val year: Int?,
    val season: String?,
    val url: String?,
    val images: Images?
)
data class Images(val jpg: ImageSet?)
data class ImageSet(val image_url: String?, val large_image_url: String?, val small_image_url: String?)

object AnimeApiProvider {
    val api: JikanApi = retrofit2.Retrofit.Builder()
        .baseUrl("https://api.jikan.moe/v4/")
        .addConverterFactory(retrofit2.converter.gson.GsonConverterFactory.create())
        .build()
        .create(JikanApi::class.java)
}

data class Anime(
    val id: Int,
    val title: String,
    val englishTitle: String?,
    val synopsis: String,
    val type: String,
    val status: String,
    val episodes: Int?,
    val score: Double?,
    val image: String?,
    val url: String?,
    val year: Int?,
    val rank: Int?
)

fun AnimeDto.toAnime() = Anime(
    mal_id, title, title_english, synopsis.orEmpty(), type.orEmpty(), status.orEmpty(),
    episodes, score, images?.jpg?.large_image_url ?: images?.jpg?.image_url, url, year, rank
)
