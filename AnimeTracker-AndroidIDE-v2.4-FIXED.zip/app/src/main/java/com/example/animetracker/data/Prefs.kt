package com.example.animetracker.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("anime_tracker")

class Prefs(private val context: Context) {
    private val favoritesKey = stringSetPreferencesKey("favorites")
    private val ratingsKey = stringSetPreferencesKey("user_ratings")
    private val progressKey = stringSetPreferencesKey("episode_progress")
    private val voiceKey = stringSetPreferencesKey("voice_preferences")
    private val qualityKey = stringSetPreferencesKey("quality_preferences")

    val favorites: Flow<Set<String>> = context.dataStore.data.map { it[favoritesKey] ?: emptySet() }

    val ratings: Flow<Map<String, Int>> = context.dataStore.data.map { prefs ->
        val raw = prefs[ratingsKey] ?: emptySet()
        raw.mapNotNull { item ->
            val p = item.split(":")
            if (p.size == 2) p[0].toIntOrNull()?.let { id -> p[1].toIntOrNull()?.let { r -> id.toString() to r } } else null
        }.toMap()
    }

    val progress: Flow<Map<String, Int>> = context.dataStore.data.map { prefs ->
        val raw = prefs[progressKey] ?: emptySet()
        raw.mapNotNull { item ->
            val p = item.split(":")
            if (p.size == 2) p[0].toIntOrNull()?.let { id -> p[1].toIntOrNull()?.let { ep -> id.toString() to ep } } else null
        }.toMap()
    }

    val voicePreferences: Flow<Map<String, String>> = context.dataStore.data.map { prefs ->
        val raw = prefs[voiceKey] ?: emptySet()
        raw.mapNotNull { item ->
            val p = item.split(":", limit = 2)
            if (p.size == 2) p[0].toIntOrNull()?.let { id -> id.toString() to p[1] } else null
        }.toMap()
    }


    val qualityPreferences: Flow<Map<String, String>> = context.dataStore.data.map { prefs ->
        val raw = prefs[qualityKey] ?: emptySet()
        raw.mapNotNull { item ->
            val p = item.split(":", limit = 2)
            if (p.size == 2) p[0].toIntOrNull()?.let { id -> id.toString() to p[1] } else null
        }.toMap()
    }
    suspend fun toggleFavorite(id: Int) {
        context.dataStore.edit { prefs ->
            val current = prefs[favoritesKey] ?: emptySet()
            prefs[favoritesKey] = if (id.toString() in current) current - id.toString() else current + id.toString()
        }
    }

    suspend fun setRating(id: Int, rating: Int) {
        context.dataStore.edit { prefs ->
            val current = (prefs[ratingsKey] ?: emptySet()).filterNot { it.startsWith("$id:") }.toMutableSet()
            current += "$id:${rating.coerceIn(1, 10)}"
            prefs[ratingsKey] = current
        }
    }

    suspend fun setProgress(id: Int, episode: Int) {
        context.dataStore.edit { prefs ->
            val current = (prefs[progressKey] ?: emptySet()).filterNot { it.startsWith("$id:") }.toMutableSet()
            current += "$id:$episode"
            prefs[progressKey] = current
        }
    }

    suspend fun setVoice(id: Int, voice: String) {
        context.dataStore.edit { prefs ->
            val current = (prefs[voiceKey] ?: emptySet()).filterNot { it.startsWith("$id:") }.toMutableSet()
            current += "$id:$voice"
            prefs[voiceKey] = current
        }
    }

    suspend fun setQuality(id: Int, quality: String) {
        context.dataStore.edit { prefs ->
            val current = (prefs[qualityKey] ?: emptySet()).filterNot { it.startsWith("$id:") }.toMutableSet()
            current += "$id:$quality"
            prefs[qualityKey] = current
        }
    }
}